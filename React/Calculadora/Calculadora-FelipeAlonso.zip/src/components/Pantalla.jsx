import React from "react";
import "./Pantalla.css";

const Pantalla = ({ value }) => {
  return <div className="pantalla">{value}</div>;
};

export default Pantalla;
