package Conversor.util;

import Conversor.modelo.Moneda;
import Modelo.MonedaVO;

import java.util.ArrayList;

public class MonedaUtil {
    static ArrayList<Moneda> monedas = new ArrayList<>();

    public MonedaUtil() {

    }

//    public static ArrayList<Moneda> parse(ArrayList<MonedaVO> monedasVO) {
//        for (MonedaVO moneda : monedasVO) {
//            monedas.add();
//        }
//    }
}
